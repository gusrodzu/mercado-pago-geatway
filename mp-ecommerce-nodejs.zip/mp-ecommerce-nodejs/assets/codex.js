/*
const mp = new MercadoPago('APP_USR-a68157fb-5513-4dc7-adbf-709ba3e46766');
const bricksBuilder = mp.bricks();
*/

/*

function initWallet(){
const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get('id');

mp.bricks().create("wallet", "wallet_container", {
   initialization: {
       preferenceId: id,
   },
});

console.log(id);
}
*/